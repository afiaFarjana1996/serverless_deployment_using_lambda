const chai  = require('chai');
const expect = chai.expect;
const getCustomerClass = require('../handlers/getCustomerData');
 
describe('getRecord', () => {
 
    it('getRecord with valid response', (done) => {
        const event = {
            body: '',
            headers: {},
            httpMethod: 'GET',
            isBase64Encoded: false,
            path: '',
            pathParameters: {"customerId":"01"},
            queryStringParameters: {},
            stageVariables: {},
            requestContext: {},
            resource: '' };

        const actualResponseBody = {
            "address" : "addressX",
            "email":"email.gmail.com",
            "firstName":"afia",
            "lastName":"farjana",
            "customerId":"01"
        }
        console.log("before unit test function");
        
      return getCustomerClass.getCustomer(event,done)
        .then( res =>{
            expect(res.statusCode).to.equal(200);
            //expect(JSON.parse(res.body)).to.deep.equal(actualResponseBody);
        })
        .catch(err => console.log("Error is: "+err))
        .finally(done)
        ;
        
     });
 
});